use test1
go

drop table [concordance]
create table [concordance] (
	[lines] nvarchar(max)
)

truncate table [concordance];

alter table [concordance] alter column [lines] varchar(max)

bulk insert [concordance]
	from 'E:\concordance.txt' with ( rowterminator='\n');
	
drop table [remove_period]
create table [remove_period] (
	[no_periods] varchar(max),
);

drop table [remove_exclaim]
create table [remove_exclaim] (
	[no_exclaims] varchar(max),
);

drop table [remove_questions]
create table [remove_questions] (
	[no_questions] varchar(max),
);

drop table [number_sentences]
create table [number_sentences] (
	[sentence] nvarchar(max),
	[line] int
)

drop table [space_split]
create table [space_split]  (
	[individual_word] nvarchar(max),
	[row] int
)

insert into [remove_period]([no_periods])
select value from [concordance]
	cross apply string_split(lines, '.');

insert into [remove_exclaim]([no_exclaims])
select value from remove_period
	cross apply string_split(no_periods, '!');

insert into [remove_questions]([no_questions])
select value from [remove_exclaim]
	cross apply string_split(no_exclaims, '?');

DELETE from [remove_questions]
where LEN([no_questions]) = 0

insert into [number_sentences]
select no_questions, ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) from [remove_questions]

drop table [wordtable]
create table [wordtable] (
	[word] nvarchar(max),
	[sentence_number] int
)

insert into [wordtable]([word], [sentence_number])
select value, line from [number_sentences]
	cross apply string_split(sentence, ' ')

DELETE from [wordtable]
where LEN([word]) = 0 

SELECT LOWER(TRIM(',:' FROM word)) as word, COUNT(word) as occurences 
FROM [wordtable]
GROUP BY word